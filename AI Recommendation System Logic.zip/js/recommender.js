/**
 * recommender.js — The recommendation engine.
 *
 * Two complementary techniques are implemented, both purely client-side:
 *
 * 1. PREFERENCE MATCHING (content-based filtering)
 *    The user's answers are turned into a "preference profile". Every item is
 *    scored against that profile with a weighted combination of:
 *      • Jaccard similarity between the user's genres and the item's genres
 *      • Jaccard similarity between the user's moods and the item's moods
 *      • Exact-match bonuses for length / era
 *      • A small boost from the item's community rating (tie-breaker)
 *    Hard filters (category, "hide items I already know") are applied first.
 *
 * 2. ITEM-TO-ITEM SIMILARITY ("Because you liked X…")
 *    Each item is converted into a binary feature vector over the shared tag
 *    vocabulary (genres + moods + length + era). Cosine similarity between
 *    vectors finds the items closest to something the user already loves.
 *
 * Every score comes with a human-readable list of reasons so the UI can
 * explain *why* something was recommended.
 */

const Recommender = (() => {

  // Weights control how much each signal contributes to the final score.
  const WEIGHTS = {
    genre: 0.50,
    mood: 0.30,
    length: 0.10,
    era: 0.05,
    rating: 0.05,
  };

  // ────────────────────────── similarity helpers ──────────────────────────

  /** Jaccard similarity: |A ∩ B| / |A ∪ B|  → 0..1 (1 = identical sets). */
  function jaccard(a, b) {
    if (!a.length && !b.length) return 0;
    const setA = new Set(a);
    const setB = new Set(b);
    let intersection = 0;
    setA.forEach(x => { if (setB.has(x)) intersection++; });
    const union = setA.size + setB.size - intersection;
    return union === 0 ? 0 : intersection / union;
  }

  /** Overlap coefficient: |A ∩ B| / |A|  — "how much of what the user asked for does the item cover?" */
  function coverage(userTags, itemTags) {
    if (!userTags.length) return 0;
    const itemSet = new Set(itemTags);
    const hits = userTags.filter(t => itemSet.has(t)).length;
    return hits / userTags.length;
  }

  function intersect(a, b) {
    const setB = new Set(b);
    return a.filter(x => setB.has(x));
  }

  // Full feature vocabulary shared by every item (for vectorisation).
  const VOCAB = [
    ...GENRES.map(g => 'genre:' + g),
    ...MOODS.map(m => 'mood:' + m),
    ...LENGTHS.map(l => 'length:' + l),
    ...ERAS.map(e => 'era:' + e),
  ];

  /** Turn an item into a binary feature vector over VOCAB. */
  function vectorize(item) {
    const features = new Set([
      ...item.genres.map(g => 'genre:' + g),
      ...item.moods.map(m => 'mood:' + m),
      'length:' + item.length,
      'era:' + item.era,
    ]);
    return VOCAB.map(f => (features.has(f) ? 1 : 0));
  }

  /** Cosine similarity between two equal-length numeric vectors → 0..1. */
  function cosine(v1, v2) {
    let dot = 0, n1 = 0, n2 = 0;
    for (let i = 0; i < v1.length; i++) {
      dot += v1[i] * v2[i];
      n1 += v1[i] * v1[i];
      n2 += v2[i] * v2[i];
    }
    if (!n1 || !n2) return 0;
    return dot / (Math.sqrt(n1) * Math.sqrt(n2));
  }

  // Pre-compute vectors once — the catalog is static.
  const VECTORS = new Map(ITEMS.map(item => [item.id, vectorize(item)]));

  // ─────────────────────── 1. preference-based scoring ───────────────────────

  /**
   * @param {Object} prefs
   *   categories : string[]  (empty = any)
   *   genres     : string[]
   *   moods      : string[]
   *   length     : 'short'|'medium'|'long'|''  ('' = any)
   *   era        : 'classic'|'modern'|''       ('' = any)
   *   exclude    : string[]  item ids to hide (e.g. things already seen)
   * @param {number} limit
   * @returns {Array<{item, score, reasons, breakdown}>}
   */
  function recommend(prefs, limit = 6) {
    const results = [];

    for (const item of ITEMS) {
      // ── hard filters ──
      if (prefs.categories.length && !prefs.categories.includes(item.category)) continue;
      if (prefs.exclude && prefs.exclude.includes(item.id)) continue;

      const reasons = [];
      const breakdown = {};

      // Genre: blend of Jaccard (penalises unrelated extra genres) and coverage (rewards hitting what was asked).
      let genreScore = 0;
      if (prefs.genres.length) {
        genreScore = 0.5 * jaccard(prefs.genres, item.genres) + 0.5 * coverage(prefs.genres, item.genres);
        const hits = intersect(prefs.genres, item.genres);
        if (hits.length) reasons.push(`Matches your genre${hits.length > 1 ? 's' : ''}: ${hits.join(', ')}`);
      } else {
        genreScore = 0.5; // neutral when the user has no genre preference
      }
      breakdown.genre = genreScore;

      // Mood
      let moodScore = 0;
      if (prefs.moods.length) {
        moodScore = 0.5 * jaccard(prefs.moods, item.moods) + 0.5 * coverage(prefs.moods, item.moods);
        const hits = intersect(prefs.moods, item.moods);
        if (hits.length) reasons.push(`Feels ${hits.join(' & ')}`);
      } else {
        moodScore = 0.5;
      }
      breakdown.mood = moodScore;

      // Length — exact match = 1, neighbouring length = 0.4, opposite = 0
      let lengthScore = 0.5;
      if (prefs.length) {
        const dist = Math.abs(LENGTHS.indexOf(prefs.length) - LENGTHS.indexOf(item.length));
        lengthScore = dist === 0 ? 1 : dist === 1 ? 0.4 : 0;
        if (dist === 0) reasons.push(`${capitalize(item.length)} time commitment, as requested`);
      }
      breakdown.length = lengthScore;

      // Era
      let eraScore = 0.5;
      if (prefs.era) {
        eraScore = item.era === prefs.era ? 1 : 0;
        if (eraScore) reasons.push(`A ${item.era} pick (${item.year})`);
      }
      breakdown.era = eraScore;

      // Rating — normalised 0..1
      const ratingScore = item.rating / 10;
      breakdown.rating = ratingScore;
      if (item.rating >= 8.8) reasons.push('Highly acclaimed');

      const score =
        WEIGHTS.genre * genreScore +
        WEIGHTS.mood * moodScore +
        WEIGHTS.length * lengthScore +
        WEIGHTS.era * eraScore +
        WEIGHTS.rating * ratingScore;

      // Skip items with zero relevance to what the user actually asked for.
      const askedSomething = prefs.genres.length || prefs.moods.length;
      if (askedSomething && genreScore === 0 && moodScore === 0) continue;

      results.push({ item, score, reasons, breakdown });
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, limit);
  }

  // ─────────────────────── 2. item-to-item similarity ───────────────────────

  /**
   * Find items most similar to a given item.
   * @param {string} itemId
   * @param {number} limit
   * @param {boolean} sameCategoryOnly
   */
  function similarTo(itemId, limit = 4, sameCategoryOnly = false) {
    const source = ITEMS.find(i => i.id === itemId);
    if (!source) return [];
    const sourceVec = VECTORS.get(itemId);

    const results = [];
    for (const item of ITEMS) {
      if (item.id === itemId) continue;
      if (sameCategoryOnly && item.category !== source.category) continue;
      // Skip the same story in a different medium (e.g. The Shining book vs film)
      if (item.title === source.title) continue;

      const score = cosine(sourceVec, VECTORS.get(item.id));
      const sharedGenres = intersect(source.genres, item.genres);
      const sharedMoods = intersect(source.moods, item.moods);
      const reasons = [];
      if (sharedGenres.length) reasons.push(`Shares ${sharedGenres.join(', ')}`);
      if (sharedMoods.length) reasons.push(`Both feel ${sharedMoods.join(' & ')}`);
      if (source.length === item.length) reasons.push(`Similar ${item.length} length`);

      results.push({ item, score, reasons });
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, limit);
  }

  // ───────────────────────────── utilities ─────────────────────────────

  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  /** Convert a 0..1 score into a friendly percentage label. */
  function matchPercent(score) { return Math.round(score * 100); }

  return { recommend, similarTo, jaccard, cosine, vectorize, matchPercent, WEIGHTS, VOCAB };
})();
