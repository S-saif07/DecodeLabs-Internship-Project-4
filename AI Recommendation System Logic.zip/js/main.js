/**
 * main.js — UI glue: reads the preference form, calls the Recommender and
 * renders result cards with explanations.
 */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const form = $('#preference-form');
  const genreChips = $('#genre-chips');
  const moodChips = $('#mood-chips');
  const seedSelect = $('#seed-select');
  const resultsGrid = $('#results-grid');
  const resultsEmpty = $('#results-empty');
  const resultsSummary = $('#results-summary');
  const similarSection = $('#similar-section');
  const similarHeading = $('#similar-heading');
  const similarGrid = $('#similar-grid');
  const cardTemplate = $('#result-card-template');

  const CATEGORY_ICON = { movie: 'fa-film', book: 'fa-book', game: 'fa-gamepad' };
  const CATEGORY_LABEL = { movie: 'Movie', book: 'Book', game: 'Game' };

  // ───────────────────────── build dynamic form controls ─────────────────────────

  function buildChips(container, name, values) {
    container.innerHTML = '';
    values.forEach(value => {
      const label = document.createElement('label');
      label.className = 'chip';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.name = name;
      input.value = value;
      const span = document.createElement('span');
      span.textContent = prettify(value);
      label.append(input, span);
      container.appendChild(label);
    });
  }

  function buildSeedOptions() {
    const groups = { movie: [], book: [], game: [] };
    ITEMS.forEach(item => groups[item.category].push(item));
    Object.entries(groups).forEach(([cat, items]) => {
      const optgroup = document.createElement('optgroup');
      optgroup.label = CATEGORY_LABEL[cat] + 's';
      items.sort((a, b) => a.title.localeCompare(b.title)).forEach(item => {
        const opt = document.createElement('option');
        opt.value = item.id;
        opt.textContent = `${item.title} (${item.year})`;
        optgroup.appendChild(opt);
      });
      seedSelect.appendChild(optgroup);
    });
  }

  function prettify(tag) {
    return tag.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('-');
  }

  // ───────────────────────────── read preferences ─────────────────────────────

  function readPrefs() {
    const data = new FormData(form);
    const seedId = data.get('seed') || '';
    const hideKnown = $('#hide-known').checked;
    return {
      categories: data.getAll('category'),
      genres: data.getAll('genre'),
      moods: data.getAll('mood'),
      length: data.get('length') || '',
      era: data.get('era') || '',
      seedId,
      exclude: seedId && hideKnown ? [seedId] : [],
    };
  }

  /**
   * If the user picked a "seed" item but selected no genres/moods, borrow the
   * seed's tags so the profile isn't empty — a common cold-start trick.
   */
  function enrichPrefsFromSeed(prefs) {
    if (!prefs.seedId) return prefs;
    const seed = ITEMS.find(i => i.id === prefs.seedId);
    if (!seed) return prefs;
    if (!prefs.genres.length) prefs.genres = [...seed.genres];
    if (!prefs.moods.length) prefs.moods = [...seed.moods];
    return prefs;
  }

  // ─────────────────────────────── rendering ───────────────────────────────

  function renderCard(result, { compact = false } = {}) {
    const { item, score, reasons, breakdown } = result;
    const node = cardTemplate.content.firstElementChild.cloneNode(true);

    const pill = $('.category-pill', node);
    pill.innerHTML = `<i class="fa-solid ${CATEGORY_ICON[item.category]}"></i> ${CATEGORY_LABEL[item.category]}`;
    pill.classList.add('cat-' + item.category);

    const pct = Recommender.matchPercent(score);
    const badge = $('.match-badge', node);
    badge.textContent = `${pct}% match`;
    badge.classList.add(pct >= 75 ? 'match-high' : pct >= 50 ? 'match-mid' : 'match-low');

    $('.card-title', node).textContent = item.title;
    $('.card-meta', node).innerHTML =
      `<span>${item.year}</span> · <span>${prettify(item.length)} length</span> · <span><i class="fa-solid fa-star"></i> ${item.rating.toFixed(1)}</span>`;
    $('.card-blurb', node).textContent = item.blurb;

    const reasonsList = $('.card-reasons', node);
    if (reasons.length) {
      reasons.slice(0, compact ? 2 : 4).forEach(r => {
        const li = document.createElement('li');
        li.innerHTML = `<i class="fa-solid fa-check"></i> ${escapeHtml(r)}`;
        reasonsList.appendChild(li);
      });
    } else {
      reasonsList.remove();
    }

    const tags = $('.card-tags', node);
    [...item.genres, ...item.moods].forEach(t => {
      const span = document.createElement('span');
      span.className = 'tag' + (item.moods.includes(t) ? ' tag-mood' : '');
      span.textContent = prettify(t);
      tags.appendChild(span);
    });

    const bars = $('.score-bars', node);
    if (breakdown && !compact) {
      [['genre', 'Genre'], ['mood', 'Mood'], ['length', 'Length'], ['era', 'Era']].forEach(([key, label]) => {
        const v = Math.round(breakdown[key] * 100);
        const row = document.createElement('div');
        row.className = 'score-bar-row';
        row.innerHTML = `<span class="score-bar-label">${label}</span>
          <span class="score-bar-track"><span class="score-bar-fill" style="width:${v}%"></span></span>
          <span class="score-bar-value">${v}%</span>`;
        bars.appendChild(row);
      });
    } else {
      bars.remove();
    }

    const moreBtn = $('.more-like-btn', node);
    if (compact) {
      moreBtn.remove();
    } else {
      moreBtn.addEventListener('click', () => showSimilar(item.id, true));
    }

    return node;
  }

  function renderResults(results, prefs) {
    resultsGrid.innerHTML = '';
    if (!results.length) {
      resultsEmpty.hidden = false;
      resultsEmpty.innerHTML = '<i class="fa-regular fa-face-frown"></i><p>No items matched those preferences. Try loosening the filters.</p>';
      resultsSummary.textContent = 'No matches found.';
      return;
    }
    resultsEmpty.hidden = true;

    const parts = [];
    if (prefs.categories.length) parts.push(prefs.categories.map(c => CATEGORY_LABEL[c] + 's').join(', '));
    if (prefs.genres.length) parts.push(prefs.genres.map(prettify).join(' / '));
    if (prefs.moods.length) parts.push(prefs.moods.map(prettify).join(' / '));
    resultsSummary.innerHTML = `Top <strong>${results.length}</strong> picks for: ${parts.length ? escapeHtml(parts.join(' · ')) : 'everything'}`;

    results.forEach((r, i) => {
      const card = renderCard(r);
      card.style.animationDelay = `${i * 60}ms`;
      resultsGrid.appendChild(card);
    });
  }

  function showSimilar(itemId, scroll = false) {
    const source = ITEMS.find(i => i.id === itemId);
    if (!source) { similarSection.hidden = true; return; }
    const similar = Recommender.similarTo(itemId, 4);
    similarHeading.innerHTML = `<i class="fa-solid fa-diagram-project"></i> Because you liked <em>${escapeHtml(source.title)}</em>`;
    similarGrid.innerHTML = '';
    similar.forEach(r => similarGrid.appendChild(renderCard(r, { compact: true })));
    similarSection.hidden = false;
    if (scroll) similarSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[c]);
  }

  // ─────────────────────────────── handlers ───────────────────────────────

  function runRecommendation() {
    const rawPrefs = readPrefs();
    updateUrl(rawPrefs);
    const prefs = enrichPrefsFromSeed(rawPrefs);
    const results = Recommender.recommend(prefs, 6);
    renderResults(results, prefs);

    if (prefs.seedId) showSimilar(prefs.seedId);
    else similarSection.hidden = true;

    $('#results-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    runRecommendation();
  });

  form.addEventListener('reset', () => {
    // Let the browser clear the inputs first, then clear results.
    setTimeout(() => {
      resultsGrid.innerHTML = '';
      similarSection.hidden = true;
      resultsEmpty.hidden = false;
      resultsEmpty.innerHTML = '<i class="fa-regular fa-compass"></i><p>Nothing here yet — your picks will appear once you submit your preferences.</p>';
      resultsSummary.innerHTML = 'Set your preferences above and hit <strong>Get recommendations</strong>.';
    }, 0);
  });

  // "Surprise me": randomly select a couple of genres and moods, then run.
  $('#surprise-btn').addEventListener('click', () => {
    form.reset();
    setTimeout(() => {
      pickRandom($$('input[name="genre"]'), 2).forEach(i => (i.checked = true));
      pickRandom($$('input[name="mood"]'), 1 + Math.floor(Math.random() * 2)).forEach(i => (i.checked = true));
      runRecommendation();
    }, 0);
  });

  function pickRandom(arr, n) {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy.slice(0, n);
  }

  // ───────────────────────── shareable URL (query params) ─────────────────────────
  // e.g. index.html?category=movie&genres=sci-fi,thriller&moods=dark&length=medium&era=modern&seed=m1

  function applyPrefsFromUrl() {
    const params = new URLSearchParams(location.search);
    if (![...params.keys()].length) return false;

    const check = (name, values) => {
      values.forEach(v => {
        const input = form.querySelector(`input[name="${name}"][value="${v}"]`);
        if (input) input.checked = true;
      });
    };
    check('category', (params.get('category') || '').split(',').filter(Boolean));
    check('genre', (params.get('genres') || '').split(',').filter(Boolean));
    check('mood', (params.get('moods') || '').split(',').filter(Boolean));
    check('length', [params.get('length') || '']);
    check('era', [params.get('era') || '']);
    if (params.get('seed')) seedSelect.value = params.get('seed');
    return true;
  }

  function updateUrl(prefs) {
    const params = new URLSearchParams();
    if (prefs.categories.length) params.set('category', prefs.categories.join(','));
    if (prefs.genres.length) params.set('genres', prefs.genres.join(','));
    if (prefs.moods.length) params.set('moods', prefs.moods.join(','));
    if (prefs.length) params.set('length', prefs.length);
    if (prefs.era) params.set('era', prefs.era);
    if (prefs.seedId) params.set('seed', prefs.seedId);
    const qs = params.toString();
    history.replaceState(null, '', qs ? `?${qs}` : location.pathname);
  }

  // ───────────────────────────────── init ─────────────────────────────────

  buildChips(genreChips, 'genre', GENRES);
  buildChips(moodChips, 'mood', MOODS);
  buildSeedOptions();
  $('#catalog-count').textContent = ITEMS.length;

  if (applyPrefsFromUrl()) runRecommendation();
})();
